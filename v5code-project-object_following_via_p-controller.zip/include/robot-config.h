using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern signature Vision18__SIG_YELLOW;
extern signature Vision18__SIG_RED;
extern signature Vision18__SIG_3;
extern signature Vision18__SIG_4;
extern signature Vision18__SIG_5;
extern signature Vision18__SIG_6;
extern signature Vision18__SIG_7;
extern vision Vision18;
extern motor fr;
extern motor br;
extern motor fl;
extern motor bl;
extern distance Distance12;
extern inertial Inertial;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );