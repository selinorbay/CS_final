#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
/*vex-vision-config:begin*/
signature Vision18__SIG_YELLOW = signature (1, 0, 0, 0, 0, 0, 0, 3, 0);
signature Vision18__SIG_RED = signature (2, 6299, 8899, 7599, -705, -171, -438, 2.6, 0);
vision Vision18 = vision (PORT18, 42, Vision18__SIG_YELLOW, Vision18__SIG_RED);
/*vex-vision-config:end*/
motor fr = motor(PORT7, ratio18_1, true);
motor br = motor(PORT6, ratio18_1, true);
motor fl = motor(PORT11, ratio18_1, true);
motor bl = motor(PORT16, ratio18_1, true);
distance Distance12 = distance(PORT12);
inertial Inertial = inertial(PORT4);

// VEXcode generated functions



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}