/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Fri Sep 27 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*    This project will detect 3 different colored objects and display        */
/*    when each object is found on the V5 Brain's screen.                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Vision18             vision        18              
// fr                   motor         7               
// br                   motor         6               
// fl                   motor         11              
// bl                   motor         16              
// Distance12           distance      12              
// Inertial             inertial      4               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "visionsensor20.h"

using namespace vex;


//P-controller with inertial integration
void inertialCheck() {
  //initial and desired value of the sensor
  int istenenDeg = 0;
  //designated an appropriate constant value for division 
  int constant = 10; 
  //for creating a deadband value while measuring degrees with the inertial sensor                                                                                                                                                                                                                                                                                           
  int offset = 30;
  //if the robot isn't perfectly aligned and does not drive straight, there's a error value created
  int sapmaPayi= 0;
  //a variable for setting speed
  int hizAyari = 0;
  int olculen = 0;

  //enters the condition if the robot is not driving straight
  if(Inertial.heading(degrees) > istenenDeg + offset || Inertial.heading(degrees)  < 360 - offset){
      
    //calculates the difference between the target degree and the measured degree
    olculen = Inertial.rotation(degrees) - istenenDeg;
    //calculates the error created with regards to how great the difference is
    sapmaPayi = 360 - olculen;
    //calculates the appropriate speed value so that robot would alling back to driving straight
    hizAyari = constant / sapmaPayi;

    //if the measured value is greater than the target degree - robot is driving slightly towards right
    if(olculen > 0){
      while(Inertial.heading(degrees) > istenenDeg + offset){
        //gives a calculated speed which is smaller than initial to right motors
        Brain.Screen.clearScreen(yellow);
        fr.spin(directionType::fwd, 100, velocityUnits::pct);
        fl.spin(directionType::fwd, 100*hizAyari, velocityUnits::pct);
        bl.spin(directionType::fwd, 100*hizAyari, velocityUnits::pct);
        br.spin(directionType::fwd, 100, velocityUnits::pct);
      }  
    }

    //if the measured value is smaller than the target degree - robot is driving slightly towards left
    if(olculen < 0){
      while(Inertial.heading(degrees) < 360 - offset){
        Brain.Screen.clearScreen(blue);
        //gives a calculated speed which is smaller than initial to right motors
        fr.spin(directionType::fwd, 100*hizAyari, velocityUnits::pct);
        fl.spin(directionType::fwd, 100, velocityUnits::pct);
        bl.spin(directionType::fwd, 100, velocityUnits::pct);
        br.spin(directionType::fwd, 100*hizAyari, velocityUnits::pct);
      }  
    }
  }

  //if the robot is driving straight inbetween the correct range
  if((Inertial.heading(degrees) < istenenDeg + offset) && (Inertial.heading(degrees)  > istenenDeg - offset)) {
    Brain.Screen.clearLine(red);
      fr.spin(directionType::fwd, 100, velocityUnits::pct);
      fl.spin(directionType::fwd, 100, velocityUnits::pct);
      bl.spin(directionType::fwd, 100, velocityUnits::pct);
      br.spin(directionType::fwd, 100, velocityUnits::pct);
     
  }
}




int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

//setting up variables for correctly training the vision sensor

//target x-axis value of the detected object
int istenenX = 150;
//a deadband for slight and insigificant errors while taking x-axis position from the sensor
int offsetX = 35;
int olculen = 0;
int x;
//target x-axis value of the detected object
int uzaklik = 300;
//a deadband for slight and insigificant errors while taking x-axis position from the sensor
int hata = 20;

//an infinite loop for continuously following an object
  while(true){

    //throughout the code 'Brain.Screen.clearScreen(?);' method is used as a debugging tool in order to keep track of entered and exited loops
    Brain.Screen.clearScreen(yellow);
    vex::task::sleep(50);

    //activates the vision sensor to determine the x-axis position of the object
    Vision18.takeSnapshot(Vision18__SIG_RED);

      //if the object is out of the boundries of the target x-axis position
      if(Vision18.largestObject.centerX > (istenenX + offsetX) || Vision18.largestObject.centerX < (istenenX - offsetX)){

        //takes another data from the sensor 
        Vision18.takeSnapshot(Vision18__SIG_RED);
        Brain.Screen.clearScreen(red);

        //determines to which direction is the robot mispositioned
        olculen = Vision18.largestObject.centerX - istenenX;
  
        //if the calculated value is positive then the robot is positioned right
        if(olculen > 0){
          
          x = 1;
        }

        //if the calculated value is positive then the robot is positioned right
        else if(olculen < 0){

          x = -1;
        }

        //While loop for continuous movement
        while(Vision18.largestObject.centerX > (istenenX + offsetX) || Vision18.largestObject.centerX < (istenenX - offsetX)) {
          Brain.Screen.clearScreen(yellow);

          //turns towards the opposite direction by setting the speeds either negative or positive
          fr.spin(directionType::rev, x*20, velocityUnits::pct);
          br.spin(directionType::rev, x*20, velocityUnits::pct);
          fl.spin(directionType::rev, x*20, velocityUnits::pct);
          bl.spin(directionType::rev, x*20, velocityUnits::pct);
          vex::task::sleep(100);
          //takes another data from the sensor to continue
          Vision18.takeSnapshot(Vision18__SIG_RED);
          }

        Brain.Screen.clearLine(red);
        fr.stop(brakeType::hold);
        fl.stop(brakeType::hold);
        bl.stop(brakeType::hold);
        br.stop(brakeType::hold);
        
      }
      
      //if the robot is positioned correctly
      if((Vision18.largestObject.centerX < istenenX + offsetX) && (Vision18.largestObject.centerX > istenenX - offsetX)) {
        Brain.Screen.clearLine(red);
        fr.stop(brakeType::hold);
        fl.stop(brakeType::hold);
        bl.stop(brakeType::hold);
        br.stop(brakeType::hold);
        vex::task::sleep(100);

        //while the correct x-axis position is satisfied, check for the distance between the object and the robot
        while((Vision18.largestObject.centerX < istenenX + offsetX) && (Vision18.largestObject.centerX > istenenX - offsetX)) {

          //if the object is out of the boundries of the target distance
          if(Distance12.objectDistance(mm) > uzaklik + hata || Distance12.objectDistance(mm) < uzaklik - hata){

            //determines wether the robot is too close or too far away from the object
            olculen = Distance12.objectDistance(mm) - uzaklik;

            if(olculen > 0){

              x = 1;
            }

            if(olculen < 0){

              x = -1;
            }

            //While loop for continuous movement
            while(Distance12.objectDistance(mm) > uzaklik + hata || Distance12.objectDistance(mm) < uzaklik - hata){
              Brain.Screen.clearScreen(yellow);
              //turns towards the opposite direction by setting the speeds either negative or positive
              fr.spin(directionType::fwd, x*10, velocityUnits::pct);
              fl.spin(directionType::rev, x*10, velocityUnits::pct);
              bl.spin(directionType::rev, x*10, velocityUnits::pct);
              br.spin(directionType::fwd, x*10, velocityUnits::pct);
              //activates the inertial p-control while aiming to drive straight 
              inertialCheck();
              vex::task::sleep(50);
              
              Vision18.takeSnapshot(Vision18__SIG_RED);
              }
            Brain.Screen.clearLine(red);
            fr.stop(brakeType::hold);
            fl.stop(brakeType::hold);
            bl.stop(brakeType::hold);
            br.stop(brakeType::hold);
            vex::task::sleep(100);
          }

        //if the robot's distance and therefore its position is correct - stop
          else if(Distance12.objectDistance(mm) < uzaklik + hata && Distance12.objectDistance(mm) > uzaklik - hata){
            while(Distance12.objectDistance(mm) < uzaklik + hata && Distance12.objectDistance(mm) > uzaklik - hata){
              Brain.Screen.clearLine(green);
              fr.stop(brakeType::hold);
              fl.stop(brakeType::hold);
              br.stop(brakeType::hold);
              bl.stop(brakeType::hold);
              vex::task::sleep(10);

              //another vision sensor value to continue
              Vision18.takeSnapshot(Vision18__SIG_RED);
              Brain.Screen.clearLine(green);
            }
              fr.stop(brakeType::hold);
              fl.stop(brakeType::hold);
              br.stop(brakeType::hold);
              bl.stop(brakeType::hold);
              //another vision sensor value to continue when while loop is exited 
              Vision18.takeSnapshot(Vision18__SIG_RED);
          }
      Brain.Screen.clearLine(green);

        }
      }

  }
}


